"""
gui/search_widget.py

The central panel of InstantBoard: the search bar plus the scrollable
grid of result cards. All network activity (searching, paginating,
downloading) happens on background QThreads so the GUI never freezes.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from myinstants.api import MyInstantsClient, MyInstantsError
from myinstants.parser import Sound
from utils.cache import CacheManager
from utils.icons import get_icon
from utils.settings import SettingsManager

logger = logging.getLogger(__name__)


# ==========================================================================
# Background workers
# ==========================================================================
class SearchWorker(QThread):
    """Runs a MyInstants search (or "load more" fetch) off the GUI thread."""

    results_ready = Signal(list, object)  # List[Sound], Optional[str] next_url
    error = Signal(str)

    def __init__(self, client: MyInstantsClient, query: Optional[str] = None, url: Optional[str] = None) -> None:
        super().__init__()
        self._client = client
        self._query = query
        self._url = url

    def run(self) -> None:
        try:
            if self._url:
                sounds, next_url = self._client.fetch_page(self._url)
            elif self._query:
                sounds, next_url = self._client.search(self._query)
            else:
                sounds, next_url = self._client.get_trending()
            self.results_ready.emit(sounds, next_url)
        except MyInstantsError as exc:
            self.error.emit(str(exc))
        except Exception as exc:  # pragma: no cover - defensive catch-all
            logger.exception("Unexpected error during search")
            self.error.emit(f"Unexpected error: {exc}")


class DownloadWorker(QThread):
    """Downloads (or reuses the cache for) a single sound, then plays it."""

    finished_ok = Signal(str, str)  # local_path, sound_id
    error = Signal(str, str)  # message, sound_id

    def __init__(self, client: MyInstantsClient, cache: CacheManager, sound: Sound) -> None:
        super().__init__()
        self._client = client
        self._cache = cache
        self._sound = sound

    def run(self) -> None:
        try:
            cached_path = self._cache.get_cached_path(self._sound.download_url)
            if cached_path is not None:
                self.finished_ok.emit(str(cached_path), self._sound.id)
                return
            data = self._client.download_sound(self._sound)
            path = self._cache.store(self._sound.download_url, data)
            self.finished_ok.emit(str(path), self._sound.id)
        except MyInstantsError as exc:
            self.error.emit(str(exc), self._sound.id)
        except Exception as exc:  # pragma: no cover
            logger.exception("Unexpected error during download")
            self.error.emit(f"Unexpected error: {exc}", self._sound.id)


# ==========================================================================
# Result card
# ==========================================================================
class SoundCard(QFrame):
    """A single result card: title, play button, favorite toggle and a
    small download-state indicator."""

    play_requested = Signal(object)  # Sound
    favorite_toggled = Signal(object, bool)  # Sound, is_favorite

    def __init__(self, sound: Sound, is_favorite: bool, is_cached: bool, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.sound = sound
        self._is_favorite = is_favorite
        self.setObjectName("Card")
        self.setFixedHeight(64)
        self.setCursor(Qt.PointingHandCursor)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(10)

        self.play_button = QPushButton()
        self.play_button.setObjectName("IconButton")
        self.play_button.setIcon(get_icon("play", 18))
        self.play_button.setFixedSize(36, 36)
        self.play_button.setToolTip("Play")
        self.play_button.clicked.connect(lambda: self.play_requested.emit(self.sound))
        layout.addWidget(self.play_button)

        title_layout = QVBoxLayout()
        title_layout.setSpacing(2)
        self.title_label = QLabel(sound.title)
        self.title_label.setWordWrap(False)
        title_layout.addWidget(self.title_label)

        self.status_label = QLabel("Cached" if is_cached else "Not downloaded")
        self.status_label.setObjectName("MutedLabel")
        title_layout.addWidget(self.status_label)
        layout.addLayout(title_layout, stretch=1)

        self.download_icon = QLabel()
        self.download_icon.setPixmap(get_icon("download", 16).pixmap(16, 16))
        self.download_icon.setVisible(not is_cached)
        layout.addWidget(self.download_icon)

        self.favorite_button = QPushButton()
        self.favorite_button.setObjectName("IconButton")
        self.favorite_button.setFixedSize(32, 32)
        self.favorite_button.setToolTip("Toggle favorite")
        self._update_favorite_icon()
        self.favorite_button.clicked.connect(self._on_favorite_clicked)
        layout.addWidget(self.favorite_button)

        # Double-click anywhere on the card also triggers play, per spec.
        self.mouseDoubleClickEvent = lambda event: self.play_requested.emit(self.sound)

    def _update_favorite_icon(self) -> None:
        icon_name = "favorite_filled" if self._is_favorite else "favorite"
        self.favorite_button.setIcon(get_icon(icon_name, 18))

    def _on_favorite_clicked(self) -> None:
        self._is_favorite = not self._is_favorite
        self._update_favorite_icon()
        self.favorite_toggled.emit(self.sound, self._is_favorite)

    def mark_cached(self) -> None:
        self.status_label.setText("Cached")
        self.download_icon.setVisible(False)

    def mark_downloading(self) -> None:
        self.status_label.setText("Downloading...")

    def mark_error(self, message: str) -> None:
        self.status_label.setText("Download failed")
        self.status_label.setToolTip(message)


# ==========================================================================
# Main search widget
# ==========================================================================
class SearchWidget(QWidget):
    """Search bar + infinite-scrolling result list."""

    sound_ready_to_play = Signal(str)  # local file path
    status_message = Signal(str)

    def __init__(self, settings: SettingsManager, cache: CacheManager, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._settings = settings
        self._cache = cache
        self._client = MyInstantsClient()

        self._search_worker: Optional[SearchWorker] = None
        self._download_workers: dict[str, DownloadWorker] = {}
        self._next_page_url: Optional[str] = None
        self._is_loading = False
        self._current_query = ""
        self._cards: List[SoundCard] = []

        self._build_ui()
        last_query = settings.get("last_search", "")
        if last_query:
            self.search_box.setText(last_query)
            self.run_search(last_query)
        else:
            self.load_trending()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(12)

        search_row = QHBoxLayout()
        search_row.setSpacing(8)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search MyInstants (e.g. 'bruh', 'airhorn', 'vine boom')...")
        self.search_box.returnPressed.connect(lambda: self.run_search(self.search_box.text()))
        search_row.addWidget(self.search_box, stretch=1)

        self.search_button = QPushButton("Search")
        self.search_button.setObjectName("PrimaryButton")
        self.search_button.setIcon(get_icon("search", 16, "#ffffff"))
        self.search_button.clicked.connect(lambda: self.run_search(self.search_box.text()))
        search_row.addWidget(self.search_button)

        self.refresh_button = QPushButton()
        self.refresh_button.setObjectName("IconButton")
        self.refresh_button.setIcon(get_icon("refresh", 18))
        self.refresh_button.setFixedSize(38, 38)
        self.refresh_button.setToolTip("Refresh")
        self.refresh_button.clicked.connect(self._on_refresh_clicked)
        search_row.addWidget(self.refresh_button)

        outer.addLayout(search_row)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.results_container = QWidget()
        self.results_layout = QVBoxLayout(self.results_container)
        self.results_layout.setSpacing(8)
        self.results_layout.setContentsMargins(2, 2, 2, 2)
        self.results_layout.addStretch(1)
        self.scroll_area.setWidget(self.results_container)
        self.scroll_area.verticalScrollBar().valueChanged.connect(self._on_scroll)
        outer.addWidget(self.scroll_area, stretch=1)

    # ------------------------------------------------------------------
    # Searching
    # ------------------------------------------------------------------
    def load_trending(self) -> None:
        self._current_query = ""
        self._start_search_worker(query=None, url=None)

    def run_search(self, query: str) -> None:
        query = query.strip()
        if not query:
            self.load_trending()
            return
        self._current_query = query
        self._settings.set("last_search", query)
        self._start_search_worker(query=query, url=None)

    def _on_refresh_clicked(self) -> None:
        if self._current_query:
            self._start_search_worker(query=self._current_query, url=None)
        else:
            self.load_trending()

    def _start_search_worker(self, query: Optional[str], url: Optional[str]) -> None:
        if self._is_loading:
            return
        self._is_loading = True
        if url is None:
            self._clear_results()
            self.status_message.emit("Searching...")
        else:
            self.status_message.emit("Loading more results...")

        self._search_worker = SearchWorker(self._client, query=query, url=url)
        self._search_worker.results_ready.connect(self._on_results_ready)
        self._search_worker.error.connect(self._on_search_error)
        self._search_worker.start()

    def _on_results_ready(self, sounds: List[Sound], next_url: Optional[str]) -> None:
        self._is_loading = False
        self._next_page_url = next_url
        for sound in sounds:
            self._add_result_card(sound)
        count = len(self._cards)
        self.status_message.emit(f"{count} result{'s' if count != 1 else ''} loaded")

    def _on_search_error(self, message: str) -> None:
        self._is_loading = False
        self.status_message.emit(f"Error: {message}")
        logger.error("Search error: %s", message)

    def _on_scroll(self, value: int) -> None:
        scrollbar = self.scroll_area.verticalScrollBar()
        near_bottom = value >= scrollbar.maximum() - 40
        if near_bottom and self._next_page_url and not self._is_loading:
            self._start_search_worker(query=None, url=self._next_page_url)

    # ------------------------------------------------------------------
    # Result list management
    # ------------------------------------------------------------------
    def _clear_results(self) -> None:
        for card in self._cards:
            card.setParent(None)
            card.deleteLater()
        self._cards.clear()
        self._next_page_url = None

    def _add_result_card(self, sound: Sound) -> None:
        is_favorite = self._settings.is_favorite(sound.id)
        is_cached = self._cache.is_cached(sound.download_url)
        card = SoundCard(sound, is_favorite, is_cached)
        card.play_requested.connect(self._on_play_requested)
        card.favorite_toggled.connect(self._on_favorite_toggled)
        # Insert before the trailing stretch item.
        self.results_layout.insertWidget(self.results_layout.count() - 1, card)
        self._cards.append(card)

    # ------------------------------------------------------------------
    # Playback / download plumbing
    # ------------------------------------------------------------------
    def _on_play_requested(self, sound: Sound) -> None:
        cached_path = self._cache.get_cached_path(sound.download_url)
        if cached_path is not None:
            self.sound_ready_to_play.emit(str(cached_path))
            return

        card = next((c for c in self._cards if c.sound.id == sound.id), None)
        if card:
            card.mark_downloading()
        self.status_message.emit(f"Downloading '{sound.title}'...")

        worker = DownloadWorker(self._client, self._cache, sound)
        worker.finished_ok.connect(self._on_download_finished)
        worker.error.connect(self._on_download_error)
        self._download_workers[sound.id] = worker
        worker.start()

    def _on_download_finished(self, local_path: str, sound_id: str) -> None:
        self._download_workers.pop(sound_id, None)
        card = next((c for c in self._cards if c.sound.id == sound_id), None)
        if card:
            card.mark_cached()
        self.status_message.emit("Ready")
        self.sound_ready_to_play.emit(local_path)

    def _on_download_error(self, message: str, sound_id: str) -> None:
        self._download_workers.pop(sound_id, None)
        card = next((c for c in self._cards if c.sound.id == sound_id), None)
        if card:
            card.mark_error(message)
        self.status_message.emit(f"Download failed: {message}")

    def _on_favorite_toggled(self, sound: Sound, is_favorite: bool) -> None:
        if is_favorite:
            self._settings.add_favorite(sound.to_dict())
        else:
            self._settings.remove_favorite(sound.id)

    def play_sound_by_dict(self, sound_dict: dict) -> None:
        """Used by the favorites list in the settings dialog to trigger
        playback of a stored favorite without it being in the current
        results list."""
        sound = Sound.from_dict(sound_dict)
        self._on_play_requested(sound)

    def shutdown(self) -> None:
        self._client.close()
