"""
gui/main_window.py

Top-level application window: assembles the top bar (title, search,
refresh, settings), the central search/results panel and the bottom
player/mixer panel. Also owns the global hotkey manager that lets
favorited sounds be triggered from anywhere on the system.
"""

from __future__ import annotations

import logging
from typing import Dict, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from audio.mixer import AudioMixer
from audio.player import PlaybackError, SoundPlayer
from gui.player_widget import PlayerWidget
from gui.search_widget import SearchWidget
from gui.settings_dialog import SettingsDialog
from myinstants.parser import Sound
from utils.cache import CacheManager
from utils.icons import get_icon
from utils.settings import SettingsManager

logger = logging.getLogger(__name__)


class GlobalHotkeyManager:
    """Wraps the optional `keyboard` package to provide system-wide
    hotkeys for favorite sounds. If `keyboard` is not installed, or the
    process lacks the permissions it needs on Windows, hotkeys are
    silently disabled and the rest of the app continues to work
    normally (in-app playback via the mouse is unaffected)."""

    def __init__(self, on_trigger) -> None:
        self._on_trigger = on_trigger
        self._registered: Dict[str, dict] = {}
        self._available = False
        try:
            import keyboard  # noqa: F401
            self._available = True
        except ImportError:
            logger.warning("The 'keyboard' package is not installed; global hotkeys are disabled.")

    @property
    def available(self) -> bool:
        return self._available

    def _to_keyboard_syntax(self, hotkey: str) -> str:
        return hotkey.lower().replace("ctrl+", "ctrl+")

    def register_all(self, hotkeys: Dict[str, dict]) -> None:
        if not self._available:
            return
        import keyboard

        self.unregister_all()
        for hotkey, sound in hotkeys.items():
            combo = self._to_keyboard_syntax(hotkey)
            try:
                keyboard.add_hotkey(combo, lambda s=sound: self._on_trigger(s))
                self._registered[hotkey] = sound
            except Exception as exc:
                logger.warning("Could not register hotkey '%s': %s", hotkey, exc)

    def unregister_all(self) -> None:
        if not self._available:
            return
        import keyboard

        try:
            keyboard.unhook_all_hotkeys()
        except Exception as exc:
            logger.warning("Could not unregister hotkeys: %s", exc)
        self._registered.clear()


class MainWindow(QMainWindow):
    """InstantBoard's main application window."""

    def __init__(self, settings: SettingsManager) -> None:
        super().__init__()
        self._settings = settings
        self._cache = CacheManager(settings.get("cache_folder", "cache"))
        self._mixer = AudioMixer()
        self._player = SoundPlayer(self._mixer)

        self.setWindowTitle("InstantBoard")
        self.setMinimumSize(1100, 700)
        self.resize(settings.get("window_width", 1200), settings.get("window_height", 800))

        self._build_ui()
        self._hotkeys = GlobalHotkeyManager(self._on_hotkey_triggered)
        self._hotkeys.register_all(self._settings.get_hotkeys())
        if not self._hotkeys.available:
            self._top_status_label.setText("Global hotkeys unavailable (install 'keyboard' package)")

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QVBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        root_layout.addWidget(self._build_top_bar())

        content_margin_widget = QWidget()
        content_layout = QVBoxLayout(content_margin_widget)
        content_layout.setContentsMargins(20, 16, 20, 16)

        self.search_widget = SearchWidget(self._settings, self._cache)
        self.search_widget.sound_ready_to_play.connect(self._on_play_local_path)
        self.search_widget.status_message.connect(self._on_status_message)
        content_layout.addWidget(self.search_widget)

        root_layout.addWidget(content_margin_widget, stretch=1)

        self.player_widget = PlayerWidget(self._settings, self._mixer)
        root_layout.addWidget(self.player_widget)

    def _build_top_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("TopBar")
        bar.setFixedHeight(64)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(20, 10, 20, 10)
        layout.setSpacing(12)

        title = QLabel("InstantBoard")
        title.setObjectName("TitleLabel")
        layout.addWidget(title)

        self._top_status_label = QLabel("")
        self._top_status_label.setObjectName("MutedLabel")
        layout.addWidget(self._top_status_label)

        layout.addStretch(1)

        settings_button = QPushButton()
        settings_button.setObjectName("IconButton")
        settings_button.setIcon(get_icon("settings", 20))
        settings_button.setFixedSize(40, 40)
        settings_button.setToolTip("Settings")
        settings_button.clicked.connect(self._open_settings)
        layout.addWidget(settings_button)

        return bar

    # ------------------------------------------------------------------
    # Playback plumbing
    # ------------------------------------------------------------------
    def _on_play_local_path(self, local_path: str) -> None:
        try:
            self._player.play(local_path)
        except PlaybackError as exc:
            logger.error("Playback failed: %s", exc)
            self._on_status_message(f"Playback failed: {exc}")

    def _on_status_message(self, message: str) -> None:
        self._top_status_label.setText(message)

    def _on_hotkey_triggered(self, sound_dict: dict) -> None:
        # Hotkeys fire on a background thread owned by the `keyboard`
        # package; downloading/playback is thread-safe by design (the
        # mixer and cache manager both use internal locks), so we can
        # call straight through without marshalling to the GUI thread
        # for the audio path itself. GUI label updates are queued
        # automatically by Qt's signal/slot mechanism across threads
        # since QLabel.setText is invoked via a queued connection here.
        try:
            cached_path = self._cache.get_cached_path(sound_dict.get("download_url", ""))
            if cached_path is None:
                sound = Sound.from_dict(sound_dict)
                from myinstants.api import MyInstantsClient

                client = MyInstantsClient()
                data = client.download_sound(sound)
                cached_path = self._cache.store(sound.download_url, data)
                client.close()
            self._player.play(cached_path)
        except Exception as exc:
            logger.error("Hotkey playback failed: %s", exc)

    # ------------------------------------------------------------------
    # Settings dialog
    # ------------------------------------------------------------------
    def _open_settings(self) -> None:
        dialog = SettingsDialog(self._settings, self._cache, self)
        dialog.favorite_play_requested.connect(self.search_widget.play_sound_by_dict)
        dialog.hotkeys_changed.connect(lambda: self._hotkeys.register_all(self._settings.get_hotkeys()))
        dialog.exec()
        self.player_widget.refresh_devices()

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------
    def closeEvent(self, event) -> None:  # noqa: N802 (Qt override naming)
        self._settings.set("window_width", self.width())
        self._settings.set("window_height", self.height())
        self._hotkeys.unregister_all()
        self.search_widget.shutdown()
        self.player_widget.shutdown()
        super().closeEvent(event)
