# InstantBoard

A modern Windows desktop soundboard that searches, downloads, caches
and plays sounds directly from [MyInstants](https://www.myinstants.com),
and can mix your microphone with soundboard clips and route the result
into voice chat / streaming apps via [VB-CABLE](https://vb-audio.com/Cable/).

---

## Features

- **Search MyInstants** directly from the app, with infinite-scrolling results
- **Download & cache** sounds locally so nothing is ever downloaded twice
- **Instant playback** - double-click or press Play; sounds overlap and never interrupt each other
- **Favorites** - star any sound for quick access later
- **Global hotkeys** - bind F1-F12 or Ctrl+letter combinations to favorite sounds, working even when InstantBoard isn't focused
- **Live mic + soundboard mixing** - continuously mixes your microphone with playing sounds
- **VB-CABLE routing** - streams the mixed audio to VB-CABLE so Discord/OBS/Zoom/etc. hear both your voice and your sounds
- **One-click Windows default device switching** - flip your system's default recording device between your normal microphone ("Normal") and VB-CABLE ("Soundboard") without touching Windows Sound settings
- **Modern dark UI** built with PySide6

---

## Requirements

- **Windows 10 or 11** (the default-device-switching feature is Windows-only; the rest of the app will run on other platforms but is not a supported target)
- **Python 3.12+**
- **[VB-CABLE](https://vb-audio.com/Cable/)** installed (free), for routing audio into other applications
- Optional: **[ffmpeg](https://ffmpeg.org/download.html)** on your PATH, used only as a fallback decoder for audio files your installed `libsndfile` version can't read directly

---

## Installation

1. Install Python 3.12 or newer from [python.org](https://www.python.org/downloads/), making sure "Add python.exe to PATH" is checked during setup.

2. Download or clone this project, then open a terminal in the project folder (`InstantBoard/`).

3. (Recommended) create a virtual environment:

   ```powershell
   python -m venv venv
   venv\Scripts\activate
   ```

4. Install dependencies:

   ```powershell
   pip install -r requirements.txt
   ```

5. Install VB-CABLE:

   - Go to https://vb-audio.com/Cable/ and download the VB-CABLE driver pack.
   - Extract it and run `VBCABLE_Setup_x64.exe` **as Administrator**.
   - Reboot when prompted. After reboot, Windows Sound settings should show
     two new devices: **CABLE Input** (a playback device) and
     **CABLE Output** (a recording device).

6. (Optional) Install ffmpeg if you want a decoding fallback for unusual
   audio encodings:

   - Download a build from https://www.gyan.dev/ffmpeg/builds/ (Windows builds)
   - Extract it and add the `bin` folder to your system PATH.

---

## Running InstantBoard

```powershell
venv\Scripts\activate
python main.py
```

The app window should open at 1200x800 (resizable, minimum 1100x700),
with a dark, modern theme.

---

## Using InstantBoard

### Searching & playing sounds

Type a query into the search bar and press Enter or click **Search**.
Results load in a scrollable list; scroll to the bottom to
automatically load more (infinite scroll). Click the play icon, or
double-click a result card, to play it immediately - it will be
downloaded and cached first if it hasn't been played before. You can
trigger many sounds in a row; each plays independently and none of
them get cut off by the next.

### Favorites

Click the star icon on any result to favorite it. Favorited sounds are
listed in **Settings -> Favorites**, where you can play or remove them.

### Hotkeys

In **Settings -> Hotkeys**, pick an available hotkey (F1-F12 or
Ctrl+A through Ctrl+Z) and one of your favorited sounds, then click
**Assign**. That hotkey will now trigger the sound from anywhere on
your system while InstantBoard is running. (Global hotkeys use the
`keyboard` package; on some systems this may require running
InstantBoard as Administrator to intercept keys system-wide.)

### Mixing your mic into voice chat / streaming apps

1. In the bottom panel, choose your microphone under **Input Device**.
2. Choose your speakers/headphones under **Output Device** - this is
   what you personally hear the soundboard through.
3. Click **Soundboard**. InstantBoard will:
   - Start continuously mixing your microphone with any sounds you play
   - Stream that mix to VB-CABLE's **CABLE Input**
   - Switch Windows' default recording device to VB-CABLE's
     **CABLE Output**
4. In Discord/OBS/Zoom/etc., select **CABLE Output** as your microphone
   (or rely on the Windows default, which InstantBoard has just set).
   That application now hears both your voice and your sounds.
5. Click **Normal** at any time to switch Windows' default recording
   device back to your real microphone and stop the soundboard mix.

### Volumes

Three independent sliders control:

- **Playback Volume** - how loud sounds are through your own speakers
- **Microphone Volume** - how loud your mic is in the mixed VB-CABLE feed
- **Soundboard Volume** - how loud sounds are in the mixed VB-CABLE feed

### Cache management

**Settings -> General** shows your cache folder and total size, and
lets you change the cache location, clear it entirely, or clean up
files older than 30 days.

---

## VB-CABLE setup summary / troubleshooting

| Symptom | Fix |
|---|---|
| "VB-CABLE not detected" warning in the status bar | Install VB-CABLE and reboot; make sure you ran the installer as Administrator |
| Soundboard button does nothing | Check that both a microphone and VB-CABLE are detected; look at `instantboard.log` for the exact error |
| Discord doesn't hear your sounds | Make sure Discord's input device is set to **CABLE Output** (Windows Voice/Video settings, or InstantBoard's "Soundboard" button which sets it as the system default automatically) |
| No sound comes out when you click Play | Check the **Output Device** selector in the bottom panel matches your real speakers/headphones |
| Crackling / glitchy audio | Try a different **Output Device**, close other audio-heavy applications, or check CPU load - the mixer uses a soft limiter but very high system load can still cause underruns |
| "Could not switch device" message | The app may need to be run as Administrator, since Windows Core Audio device switching sometimes requires elevated permissions depending on system configuration |
| Global hotkeys don't fire | Ensure the `keyboard` package installed correctly, and consider running as Administrator - `keyboard` needs elevated permissions to capture global key combinations reliably on Windows |

---

## Project structure

```
InstantBoard/
    main.py                  Entry point
    gui/
        main_window.py       Top-level window, top bar, hotkey wiring
        search_widget.py      Search bar, result cards, background workers
        player_widget.py      Bottom panel: volumes, devices, mic switch
        settings_dialog.py    Settings dialog: cache, favorites, hotkeys
    audio/
        mixer.py              Real-time mic + soundboard mixing engine
        player.py              Decoding + high-level play API
        devices.py             Device enumeration, VB-CABLE detection, Windows default device switching
        recorder.py            Continuous microphone capture
    myinstants/
        api.py                 HTTP client for myinstants.com
        parser.py               BeautifulSoup HTML parsing
    utils/
        cache.py                On-disk sound cache
        settings.py             JSON-backed settings manager
        icons.py                 Vector icon rendering (no binary assets needed)
    resources/
        theme.py                 Dark theme Qt stylesheet
    cache/                       Default cache folder (created automatically)
    requirements.txt
    README.md
```

---

## Notes on design decisions

- **No binary icon assets**: icons are rendered on the fly with
  `QPainter` in `utils/icons.py`, so the project has zero missing-asset
  risk and stays fully self-contained.
- **Windows default device switching** uses the same undocumented
  `IPolicyConfig` COM interface that Windows' own Sound control panel
  uses internally (there is no public Win32 API for this). It is
  implemented via `pycaw` (endpoint enumeration) and `comtypes`
  (the `SetDefaultEndpoint` call).
- **Dual audio outputs**: a background render thread advances every
  playing sound's position exactly once per audio block and pushes
  copies into two independent queues, so the "monitor" (your speakers)
  and "broadcast" (VB-CABLE) outputs always play sounds in perfect
  sync without one starving or double-consuming the other.
- **Threading**: all network I/O (search, pagination, downloads) runs
  on `QThread` workers; all audio I/O runs on PortAudio's own callback
  threads plus one internal render thread. The Qt GUI thread never
  performs blocking work.
