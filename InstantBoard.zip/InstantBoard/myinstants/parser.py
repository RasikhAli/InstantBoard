"""
myinstants/parser.py

BeautifulSoup-based parsing of MyInstants HTML pages into structured
Sound records. Kept separate from api.py so that the scraping logic
can evolve independently of the HTTP/session handling, and so it can
be unit tested against saved HTML fixtures without a network call.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import List, Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

BASE_URL = "https://www.myinstants.com"


@dataclass
class Sound:
    """A single sound result scraped from MyInstants."""

    id: str
    title: str
    play_url: str
    download_url: str
    detail_url: Optional[str] = None
    duration: Optional[float] = None
    thumbnail_url: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "play_url": self.play_url,
            "download_url": self.download_url,
            "detail_url": self.detail_url,
            "duration": self.duration,
            "thumbnail_url": self.thumbnail_url,
        }

    @staticmethod
    def from_dict(data: dict) -> "Sound":
        return Sound(
            id=data["id"],
            title=data["title"],
            play_url=data["play_url"],
            download_url=data["download_url"],
            detail_url=data.get("detail_url"),
            duration=data.get("duration"),
            thumbnail_url=data.get("thumbnail_url"),
        )


def _make_sound_id(onclick_value: str, href_fallback: str = "") -> str:
    """MyInstants buttons look like:

        <div class="instant" onclick="play('/media/sounds/foo.mp3')">

    We derive a stable ID from the mp3 path, since it never changes.
    """
    match = re.search(r"play\('([^']+)'", onclick_value)
    path = match.group(1) if match else href_fallback
    return re.sub(r"[^a-zA-Z0-9]+", "-", path).strip("-").lower()


def parse_search_results(html: str) -> List[Sound]:
    """Parse a MyInstants search (or homepage / category) results page.

    The site renders each sound as a `div.instant` element containing:
      - a small play button with an `onclick="play('/media/....mp3')"`
        attribute holding the *playable* (streamed) URL
      - an anchor `a.instant-link` with the human-readable title and a
        link to the sound's detail page
      - a download button `.instant-link-buttons a[href$='.mp3']` (not
        always present; when absent we fall back to the play URL)
    """
    soup = BeautifulSoup(html, "html.parser")
    sounds: List[Sound] = []

    for node in soup.select("div.instant"):
        onclick = node.get("onclick", "") or ""
        media_match = re.search(r"play\('([^']+)'", onclick)
        if not media_match:
            continue
        media_path = media_match.group(1)
        play_url = urljoin(BASE_URL, media_path)

        title_anchor = node.select_one("a.instant-link")
        title = title_anchor.get_text(strip=True) if title_anchor else "Untitled"
        detail_href = title_anchor.get("href") if title_anchor else None
        detail_url = urljoin(BASE_URL, detail_href) if detail_href else None

        download_anchor = node.select_one("a[href$='.mp3'], a.instant-link-buttons a")
        if download_anchor and download_anchor.get("href", "").endswith(".mp3"):
            download_url = urljoin(BASE_URL, download_anchor["href"])
        else:
            download_url = play_url

        sound_id = _make_sound_id(onclick, media_path)

        sounds.append(
            Sound(
                id=sound_id,
                title=title,
                play_url=play_url,
                download_url=download_url,
                detail_url=detail_url,
            )
        )

    logger.debug("Parsed %d sound(s) from search results page", len(sounds))
    return sounds


def has_next_page(html: str) -> bool:
    """Return True if a "load more" / next-page control is present."""
    soup = BeautifulSoup(html, "html.parser")
    next_link = soup.select_one("a.pagination-next, li.next a, a[rel='next']")
    return next_link is not None


def extract_next_page_url(html: str, current_url: str) -> Optional[str]:
    """Extract the URL of the next results page, if any."""
    soup = BeautifulSoup(html, "html.parser")
    next_link = soup.select_one("a.pagination-next, li.next a, a[rel='next']")
    if next_link and next_link.get("href"):
        return urljoin(current_url, next_link["href"])
    return None
