"""
audio/devices.py

Audio device enumeration (via sounddevice/PortAudio) plus Windows-only
functionality to detect VB-CABLE and to switch the *system default*
recording/playback device.

Device enumeration for the GUI (drop-down lists, VB-CABLE detection)
uses `sounddevice`, which works cross-platform and is what the mixer
and player also use to open audio streams.

Switching the *Windows system default* endpoint requires talking to
Windows Core Audio directly. There is no public Win32 API for this;
the Sound control panel itself calls an internal COM interface named
`IPolicyConfig`. This is a well-known technique used by common,
legitimate audio-switching utilities and is implemented here using
`pycaw` (for robust IMMDevice / property-store access) plus a small
custom COM interface binding for the `SetDefaultEndpoint` method that
pycaw itself does not expose.
"""

from __future__ import annotations

import logging
import platform
from dataclasses import dataclass
from typing import List, Optional

import sounddevice as sd

logger = logging.getLogger(__name__)

IS_WINDOWS = platform.system() == "Windows"


@dataclass
class AudioDevice:
    """A single audio device as reported by PortAudio."""

    index: int
    name: str
    max_input_channels: int
    max_output_channels: int
    default_samplerate: float
    hostapi: int

    @property
    def is_input(self) -> bool:
        return self.max_input_channels > 0

    @property
    def is_output(self) -> bool:
        return self.max_output_channels > 0

    @property
    def is_vb_cable_input(self) -> bool:
        """True if this is the 'CABLE Output' recording endpoint, i.e.
        what you'd record *from* to capture InstantBoard's mixed audio."""
        return "cable output" in self.name.lower()

    @property
    def is_vb_cable_output(self) -> bool:
        """True if this is the 'CABLE Input' playback endpoint InstantBoard
        should render its mixed audio to."""
        return "cable input" in self.name.lower()


def list_devices() -> List[AudioDevice]:
    """Return every audio device PortAudio can see."""
    devices = []
    try:
        raw_devices = sd.query_devices()
    except Exception as exc:  # pragma: no cover - defensive, PortAudio init issues
        logger.error("Failed to query audio devices: %s", exc)
        return []

    for idx, info in enumerate(raw_devices):
        devices.append(
            AudioDevice(
                index=idx,
                name=info.get("name", f"Device {idx}"),
                max_input_channels=info.get("max_input_channels", 0),
                max_output_channels=info.get("max_output_channels", 0),
                default_samplerate=info.get("default_samplerate", 44100.0),
                hostapi=info.get("hostapi", 0),
            )
        )
    return devices


def list_input_devices() -> List[AudioDevice]:
    return [d for d in list_devices() if d.is_input]


def list_output_devices() -> List[AudioDevice]:
    return [d for d in list_devices() if d.is_output]


def find_vb_cable_input() -> Optional[AudioDevice]:
    """Find the 'CABLE Output' recording endpoint (i.e. what you'd record
    from to hear InstantBoard's mixed output)."""
    for device in list_input_devices():
        if device.is_vb_cable_input:
            return device
    return None


def find_vb_cable_output() -> Optional[AudioDevice]:
    """Find the 'CABLE Input' playback endpoint InstantBoard should render to."""
    for device in list_output_devices():
        if device.is_vb_cable_output:
            return device
    return None


def is_vb_cable_installed() -> bool:
    return find_vb_cable_input() is not None or find_vb_cable_output() is not None


# ==========================================================================
# Windows default recording/playback device switching
# ==========================================================================

_POLICY_CONFIG_CLSID = "{870af99c-171d-4f9e-af0d-e63df40c2bc9}"
_IPOLICY_CONFIG_IID = "{f8679f50-850a-41cf-9c72-430f290290c8}"

E_ROLE_CONSOLE = 0
E_ROLE_MULTIMEDIA = 1
E_ROLE_COMMUNICATIONS = 2


class DeviceSwitchError(Exception):
    """Raised when the Windows default audio device cannot be changed."""


class WindowsDefaultDeviceSwitcher:
    """Switches the Windows *system default* recording/playback device.

    This class only functions on Windows and only when `pycaw` and
    `comtypes` are installed. On any other platform, or if COM setup
    fails, every method raises `DeviceSwitchError` with a clear
    explanation so the GUI can show a friendly warning instead of
    crashing.
    """

    def __init__(self) -> None:
        self._available = False
        self._error: Optional[str] = None
        if not IS_WINDOWS:
            self._error = "Default device switching is only supported on Windows."
            return
        try:
            import comtypes  # noqa: F401
            from pycaw.pycaw import AudioUtilities  # noqa: F401
            self._available = True
        except ImportError as exc:
            self._error = f"Missing dependency for device switching: {exc}"

    @property
    def available(self) -> bool:
        return self._available

    @property
    def error(self) -> Optional[str]:
        return self._error

    # ------------------------------------------------------------------
    # Endpoint resolution
    # ------------------------------------------------------------------
    def _find_endpoint_id(self, friendly_name_substring: str, capture: bool) -> str:
        """Resolve a friendly device name (as reported by PortAudio) to a
        Windows Core Audio endpoint ID string, using pycaw's AudioUtilities
        (which itself wraps IMMDeviceEnumerator/IMMDevice/IPropertyStore)."""
        from pycaw.pycaw import AudioUtilities, DEVICE_STATE

        target = friendly_name_substring.lower()
        matches = []
        try:
            devices = AudioUtilities.GetAllDevices()
        except Exception as exc:
            raise DeviceSwitchError(f"Could not enumerate audio endpoints: {exc}") from exc

        for device in devices:
            try:
                if device.state != DEVICE_STATE.ACTIVE.value:
                    continue
                if device.FriendlyName and target in device.FriendlyName.lower():
                    matches.append(device)
            except Exception:
                continue

        if not matches:
            raise DeviceSwitchError(
                f"Could not find a Windows audio endpoint matching '{friendly_name_substring}'."
            )
        return matches[0].id

    # ------------------------------------------------------------------
    # Public switching API
    # ------------------------------------------------------------------
    def set_default_recording_device(self, device_name: str) -> None:
        """Set the Windows system default *recording* device to the
        endpoint whose friendly name contains `device_name`."""
        self._set_default_device(device_name, capture=True)

    def set_default_playback_device(self, device_name: str) -> None:
        """Set the Windows system default *playback* device to the
        endpoint whose friendly name contains `device_name`."""
        self._set_default_device(device_name, capture=False)

    def _set_default_device(self, device_name: str, capture: bool) -> None:
        if not self._available:
            raise DeviceSwitchError(self._error or "Default device switching unavailable.")

        import comtypes
        from comtypes import GUID, COMMETHOD, HRESULT, IUnknown, CoCreateInstance, CLSCTX_INPROC_SERVER
        import ctypes

        comtypes.CoInitialize()
        try:
            device_id = self._find_endpoint_id(device_name, capture)

            class IPolicyConfig(IUnknown):
                """Minimal binding of the undocumented IPolicyConfig
                interface, exposing only SetDefaultEndpoint (the method
                the Windows Sound control panel uses internally). The
                preceding vtable slots must still be declared, even
                though InstantBoard never calls them, so that the vtable
                offsets line up correctly."""

                _iid_ = GUID(_IPOLICY_CONFIG_IID)
                _methods_ = [
                    COMMETHOD([], HRESULT, "GetMixFormat"),
                    COMMETHOD([], HRESULT, "GetDeviceFormat"),
                    COMMETHOD([], HRESULT, "ResetDeviceFormat"),
                    COMMETHOD([], HRESULT, "SetDeviceFormat"),
                    COMMETHOD([], HRESULT, "GetProcessingPeriod"),
                    COMMETHOD([], HRESULT, "SetProcessingPeriod"),
                    COMMETHOD([], HRESULT, "GetShareMode"),
                    COMMETHOD([], HRESULT, "SetShareMode"),
                    COMMETHOD([], HRESULT, "GetPropertyValue"),
                    COMMETHOD([], HRESULT, "SetPropertyValue"),
                    COMMETHOD(
                        [],
                        HRESULT,
                        "SetDefaultEndpoint",
                        (["in"], ctypes.c_wchar_p, "deviceId"),
                        (["in"], ctypes.c_int, "role"),
                    ),
                    COMMETHOD([], HRESULT, "SetEndpointVisibility"),
                ]

            policy_config = CoCreateInstance(
                GUID(_POLICY_CONFIG_CLSID),
                interface=IPolicyConfig,
                clsctx=CLSCTX_INPROC_SERVER,
            )

            for role in (E_ROLE_CONSOLE, E_ROLE_MULTIMEDIA, E_ROLE_COMMUNICATIONS):
                policy_config.SetDefaultEndpoint(device_id, role)

            logger.info(
                "Switched default %s device to '%s'",
                "recording" if capture else "playback",
                device_name,
            )
        except DeviceSwitchError:
            raise
        except Exception as exc:
            logger.error("Failed to switch default device: %s", exc)
            raise DeviceSwitchError(str(exc)) from exc
        finally:
            comtypes.CoUninitialize()
